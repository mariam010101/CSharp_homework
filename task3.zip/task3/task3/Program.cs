﻿using System;
using System.Diagnostics;

namespace task3
{
    public interface ISortStrategy
    {
        void Sort(int[] array);
    }

    public class InsertionSort : ISortStrategy
    {
        public void Sort(int[] array)
        {
            for (int i = 1; i < array.Length; i++)
            {
                int key = array[i];
                int j = i - 1;
                while (j >= 0 && array[j] > key)
                {
                    array[j + 1] = array[j];
                    j--;
                }
                array[j + 1] = key;
            }
        }
    }

    public class SelectionSort : ISortStrategy
    {
        public void Sort(int[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                int minIdx = i;
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[j] < array[minIdx])
                        minIdx = j;
                }
                (array[i], array[minIdx]) = (array[minIdx], array[i]);
            }
        }
    }

    public class MergeSort : ISortStrategy
    {
        public void Sort(int[] array)
        {
            MergeSortRecursive(array, 0, array.Length - 1);
        }

        private void MergeSortRecursive(int[] array, int left, int right)
        {
            if (left < right)
            {
                int mid = (left + right) / 2;
                MergeSortRecursive(array, left, mid);
                MergeSortRecursive(array, mid + 1, right);
                Merge(array, left, mid, right);
            }
        }

        private void Merge(int[] array, int left, int mid, int right)
        {
            int n1 = mid - left + 1;
            int n2 = right - mid;

            int[] leftArray = new int[n1];
            int[] rightArray = new int[n2];

            Array.Copy(array, left, leftArray, 0, n1);
            Array.Copy(array, mid + 1, rightArray, 0, n2);

            int i = 0, j = 0, k = left;
            while (i < n1 && j < n2)
            {
                if (leftArray[i] <= rightArray[j])
                    array[k++] = leftArray[i++];
                else
                    array[k++] = rightArray[j++];
            }

            while (i < n1) array[k++] = leftArray[i++];
            while (j < n2) array[k++] = rightArray[j++];
        }
    }

    public class ShellSort : ISortStrategy
    {
        public void Sort(int[] array)
        {
            int n = array.Length;
            for (int gap = n / 2; gap > 0; gap /= 2)
            {
                for (int i = gap; i < n; i++)
                {
                    int temp = array[i];
                    int j;
                    for (j = i; j >= gap && array[j - gap] > temp; j -= gap)
                        array[j] = array[j - gap];
                    array[j] = temp;
                }
            }
        }
    }

    public class SortContext
    {
        private ISortStrategy _strategy;

        public void SetStrategy(ISortStrategy strategy)
        {
            _strategy = strategy;
        }

        public void ExecuteStrategy(int[] array)
        {
            _strategy.Sort(array);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            SortContext context = new SortContext();

            RunSort("Insertion Sort", new InsertionSort(), 3000, context);
            RunSort("Selection Sort", new SelectionSort(), 3000, context);
            RunSort("Merge Sort", new MergeSort(), 10000, context);
            RunSort("Shell Sort", new ShellSort(), 10000, context);

            Console.WriteLine("\nAll sorts completed. Press Enter to exit.");
            Console.ReadLine();
        }

        static void RunSort(string name, ISortStrategy strategy, int size, SortContext context)
        {
            int[] array = GenerateRandomArray(size);
            context.SetStrategy(strategy);

            Stopwatch sw = Stopwatch.StartNew();
            context.ExecuteStrategy(array);
            sw.Stop();

            Console.WriteLine($"{name,-20}: {sw.ElapsedMilliseconds} ms");
        }

        static int[] GenerateRandomArray(int size)
        {
            Random rand = new Random();
            int[] arr = new int[size];
            for (int i = 0; i < size; i++)
                arr[i] = rand.Next(0, 10000);
            return arr;
        }
    }
}
