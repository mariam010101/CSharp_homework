﻿/* We have Array vector. Program a Bubble, Insertion and Selection sorting with Template Method pattern
that have overlapping code segments. Compare execution speeds. Implement with C# Console Application.*/


using System;
using System.Diagnostics;

namespace Task2
{
    public abstract class SortAlgorithm<T> where T : IComparable<T>
    {
        public void SortAndMeasure(T[] array)
        {
            Console.WriteLine($"Starting {GetAlgorithmName()}...");

            T[] arrayCopy = new T[array.Length];
            Array.Copy(array, arrayCopy, array.Length);

            var stopwatch = Stopwatch.StartNew();
            Sort(arrayCopy);
            stopwatch.Stop();

            VerifySort(arrayCopy);

            Console.WriteLine($"{GetAlgorithmName()} completed in {stopwatch.ElapsedMilliseconds} ms\n");
        }

        protected abstract void Sort(T[] array);
        protected abstract string GetAlgorithmName();

        protected void Swap(T[] array, int i, int j)
        {
            T temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }

        private void VerifySort(T[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                if (array[i].CompareTo(array[i + 1]) > 0)
                {
                    Console.WriteLine("!!! Sort verification failed!");
                    return;
                }
            }
            Console.WriteLine("Sort verified successfully");
        }
    }

    public class BubbleSort<T> : SortAlgorithm<T> where T : IComparable<T>
    {
        protected override void Sort(T[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                for (int j = 0; j < array.Length - i - 1; j++)
                {
                    if (array[j].CompareTo(array[j + 1]) > 0)
                    {
                        Swap(array, j, j + 1);
                    }
                }
            }
        }

        protected override string GetAlgorithmName() => "Bubble Sort";
    }

    public class InsertionSort<T> : SortAlgorithm<T> where T : IComparable<T>
    {
        protected override void Sort(T[] array)
        {
            for (int i = 1; i < array.Length; i++)
            {
                T key = array[i];
                int j = i - 1;

                while (j >= 0 && array[j].CompareTo(key) > 0)
                {
                    array[j + 1] = array[j];
                    j--;
                }
                array[j + 1] = key;
            }
        }

        protected override string GetAlgorithmName() => "Insertion Sort";
    }

    public class SelectionSort<T> : SortAlgorithm<T> where T : IComparable<T>
    {
        protected override void Sort(T[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[j].CompareTo(array[minIndex]) < 0)
                    {
                        minIndex = j;
                    }
                }
                if (minIndex != i)
                {
                    Swap(array, i, minIndex);
                }
            }
        }

        protected override string GetAlgorithmName() => "Selection Sort";
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                const int arraySize = 10000;
                var random = new Random();
                var originalArray = new int[arraySize];

                for (int i = 0; i < arraySize; i++)
                {
                    originalArray[i] = random.Next(0, 100000);
                }

                Console.WriteLine($"Sorting {arraySize} elements...\n");

                var bubbleSort = new BubbleSort<int>();
                var insertionSort = new InsertionSort<int>();
                var selectionSort = new SelectionSort<int>();

                bubbleSort.SortAndMeasure(originalArray);
                insertionSort.SortAndMeasure(originalArray);
                selectionSort.SortAndMeasure(originalArray);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}